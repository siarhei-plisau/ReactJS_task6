import React from 'react';
import {
  logIn,
  changeUserName,
  changePassword,
  checkErrorLogin,
 } from '../../redux/actions';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import styles from './FormLogin.module.scss';

const FormLogin = (props) => {
  const {
    userName,
    password,
    logIn,
    users,
    errorLogin,
    handleChangeUserName,
    handleChangePassword,
    checkErrorLogin,
  } = props;

const handleLogIn = (e) => {
  e.preventDefault();
  const currentUser = users.filter( (item) => (userName === item.userName && password === item.password))
    if ( currentUser.length > 0) {
      logIn(currentUser[0]);
    } else {
      checkErrorLogin(true);
      handleChangeUserName('');
      handleChangePassword('');
    }
}

  return (
    <form onSubmit={handleLogIn} className={styles.formLogin}>
      { errorLogin ? 
        <div className={styles.errorLogin}>Error! Registration can't be completed.</div> :
        null
      }
      <label>
        User name
        <input
          type="text"
          className={styles.userName}
          value={userName}
          required
          onChange={(e) => { handleChangeUserName(e.target.value) }}
        />
      </label>

      <label>
        Password
        <input
          type="password"
          className={styles.password}
          value={password}
          required
          onChange={(e) => { handleChangePassword(e.target.value) }}
        />
      </label>
      <button type="submit">Log In</button>
    </form>
  )
}

const mapStateToProps = state => {
  return {
    userName: state.access.userName,
    password: state.access.password,
    users: state.access.users,
    errorLogin: state.access.errorLogin
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    handleChangeUserName: bindActionCreators(changeUserName, dispatch),
    handleChangePassword: bindActionCreators(changePassword, dispatch),
    logIn: bindActionCreators(logIn, dispatch),
    checkErrorLogin: bindActionCreators(checkErrorLogin, dispatch),
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(FormLogin);
