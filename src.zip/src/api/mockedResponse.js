export const mockedResponse = [
  {
    id: 1,
    price: 56,
    title: 'SSD Kingston A400',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/25678797282125a6831ff123423630a8.jpg',
    about: '2.5"/SATA 3.0/TLC',
  },
  {
    id: 2,
    price: 30,
    title: 'ExeGate',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/b501fc6e5eb7bba5959b1266c2065285.jpg',
    about: 'ATX/350W',
  },
  {
    id: 3,
    price: 194,
    title: 'Radeon RX550',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/d3c945ab2aded453bbb7069557d7dfb6.jpg',
    about: '2Gb/GDDR5/128Bit',
  },
  {
    id: 4,
    price: 100,
    title: 'Toshiba P300',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/dc156fc60aa285c31fc1e4a213dd9992.jpg',
    about: '1Tb/7200/sata 3',
  },
  {
    id: 5,
    price: 144,
    title: 'Gigabyte AB-350',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/3cdc5d14f571a4714a0f6e561cbb8568.jpg',
    about: 'mATX/AM4/B350',
  },
  {
    id: 6,
    price: 53,
    title: 'Crusial Ballistix',
    imageUrl: 'https://s8.hostingkartinok.com/uploads/images/2020/08/aff9811d0c67fd445118a7cac54b2e1c.jpg',
    about: '4Gb/2400Mhz/CL16T',
  }
];