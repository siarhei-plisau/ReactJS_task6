export const logIn = (user) => ({
    type: 'LOG_IN',
    payload: true,
    user,
  });

export const logOut= () => ({
  type: 'LOG_OUT',
  payload: false
}); 

export const changeUserName = (userName) => ({
  type: 'CHANGE_USERNAME',
  payload: userName
});

export const changePassword = (password) => ({
  type: 'CHANGE_PASSWORD',
  payload: password
});

export const checkErrorLogin = (value) => ({
  type: 'CHECK_ERRORLOGIN',
  payload: value
}); 