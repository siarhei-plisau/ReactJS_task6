import { createStore, applyMiddleware } from 'redux';
import  rootReducer from '../reducers/index'; 
import thunk from 'redux-thunk';

const initialState = {
  operationsWithCards: {
    isLoading: false,
    cards: [],
    price: '',
    title: '',
    imageUrl: '',
    about: '',
    errorForm: {
      price: false,
      title: false,
      imageUrl: false,
      about: false,
      },
  },
  access: {
    isAuthenticated: false,
    userName: '',
    password: '',
    errorLogin: false,
    currentUser: {},
    users: [
      {
        id: 0,
        firstName: 'Emily',
        lastName: 'Chambers',
        avatarImage: 'https://s8.hostingkartinok.com/uploads/images/2020/09/e72e2cac24488d5edc789d6a63fbea92.jpg',
        userName: 'cat_4321',
        password: 'cat_4321',
        profession: 'Photographer',
        about: `Mauris porttitor, nibh
          at sagittis tristique, enim magna pretium
          augue, eget consectetur sem dui non urna. Morbi egestas
          sit amet velit eget venenatis.`,
      },
      {
        id: 1,
        firstName: 'Andrew',
        lastName: 'Hopkins',
        avatarImage: 'https://s8.hostingkartinok.com/uploads/images/2020/08/91fe43e4401e57b2130b4a0be50bf28c.png',
        userName: 'fox_1234',
        password: 'fox_1234',
        profession: 'Illustrator & Character Designer',
        about: `Lorem ipsum dolor sit amet, consectetur
          adipiscing elit. Integer gravida, diam congue molestie
          fringilla, elit odio rhoncus turpis, ac
          dictum libero elit vel metus.`,
      },
    ]
    
  }
}
export const store = createStore(rootReducer, initialState, applyMiddleware(thunk));
